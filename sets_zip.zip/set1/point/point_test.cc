#include "point.h"
#include <gtest/gtest.h>

namespace{
TEST(Point,ParameterizedConstructor) {
    Point a1(0,6);
    EXPECT_EQ(6,a1.distancefromorigin());
}
}
