#include "complex.h"
#include <iostream>
//using namespace std;

template <class T>
Complex<T> :: Complex(): m_real(0),m_imag(0){}
template <class T>
Complex<T> :: Complex(T real,T imag): m_real(real),m_imag(imag){}
template <class T>
T Complex<T> :: real(){
    return m_real;
}
template <class T>
T Complex<T> :: imag(){
    return m_imag;
}
template <class T>
void Complex<T> :: display(){
    std::cout << m_real << "+i" << m_imag;
}








