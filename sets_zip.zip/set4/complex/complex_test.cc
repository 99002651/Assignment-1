#include "complex.h"
#include "complex.cc"
#include "gtest/gtest.h"

namespace{

TEST(Complex,DefaultParameters){
    Complex<int> c;
    std :: string ExpectedOut = "0+i0";
     testing::internal::CaptureStdout();
     c.display();
    std :: string ActualOut  =  testing::internal::GetCapturedStdout();
    EXPECT_STREQ( ExpectedOut.c_str(),ActualOut.c_str());
  }
TEST(a,b){
	Complex<int> p1(1,1);
	ASSERT_EQ(1, p1.real());
	ASSERT_EQ(1, p1.imag());
	std::string ExpectedOut="1+i1";
	testing::internal::CaptureStdout();
	p1.display();
	std::string ActualOut = testing::internal::GetCapturedStdout();
	EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
  }
}

