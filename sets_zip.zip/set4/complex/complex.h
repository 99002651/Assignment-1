#pragma here
#ifndef __COMPLEX_H_
#define __COMPLEX_H_
template <class T>
class Complex
{
private:
    T m_real;
    T m_imag;
public:
    Complex();
    Complex(T,T);
    T real();
    T imag();
    void display();
};
#endif
