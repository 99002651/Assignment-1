#include "polygon.h"

Polygon:: Polygon(int n):m_sides(n){}
Polygon::Polygon(){}
