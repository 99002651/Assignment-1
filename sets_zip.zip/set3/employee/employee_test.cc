
#include<gtest/gtest.h>
#include"employee.h"
#include"manager.h"
#include"trainee.h"
#include"employee.h"
#include"engineer.h"

TEST(Engineer,Test1)
{
    Engineer e1("id","name", 4856, 789, 45);
    e1.appraisal(100);
    EXPECT_EQ(4956,e1.payroll());
}

