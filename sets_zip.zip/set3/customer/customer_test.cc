#include"customer.h"
#include"prepaid.h"
#include"postpaid.h"
#include<gtest/gtest.h>
using namespace std;
TEST(PrepaidCustomer,DefaultConstructor) {
    PrepaidCustomer a1;
    EXPECT_EQ(0.0,a1.getBalance());
    EXPECT_STREQ("0000",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("No Name",a1.getCustomerName().c_str());
    EXPECT_STREQ("No Number",a1.getCustomerPhone().c_str());
}
TEST(PrepaidCustomer,ParameterizedConstructor) {
    PrepaidCustomer a1("1001","Lippman","9611044790",5000.0);
    EXPECT_STREQ("1001",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a1.getCustomerName().c_str());
    EXPECT_STREQ("9611044790",a1.getCustomerPhone().c_str());
    EXPECT_EQ(5000.0,a1.getBalance());
}
TEST(PrepaidCustomer,CopyConstructor) {
    PrepaidCustomer a1("1001","Lippman","9611044790",5000.0);
    PrepaidCustomer a2(a1);
    EXPECT_STREQ("1001",a2.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a2.getCustomerName().c_str());
    EXPECT_STREQ("9611044790",a2.getCustomerPhone().c_str());
    EXPECT_EQ(5000.0,a2.getBalance());
}
TEST(PostpaidCustomer,DefaultConstructor) {
    PostpaidCustomer a1;
    EXPECT_EQ(0.0,a1.getBalance());
    EXPECT_STREQ("0000",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("No Name",a1.getCustomerName().c_str());
    EXPECT_STREQ("No Number",a1.getCustomerPhone().c_str());
}
TEST(PostpaidCustomer,ParameterizedConstructor) {
    PostpaidCustomer a1("1001","Lippman","9611044790",5000.0,25);
    EXPECT_STREQ("1001",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a1.getCustomerName().c_str());
    EXPECT_STREQ("9611044790",a1.getCustomerPhone().c_str());
    EXPECT_EQ(5000.0,a1.getBalance());
}
TEST(PostpaidCustomer,CopyConstructor) {
    PostpaidCustomer a1("1001","Lippman","9611044790",5000.0,25);
    PostpaidCustomer a2(a1);
    EXPECT_STREQ("1001",a2.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a2.getCustomerName().c_str());
    EXPECT_STREQ("9611044790",a2.getCustomerPhone().c_str());
    EXPECT_EQ(5000.0,a2.getBalance());
}
TEST(PrepaidCustomer,CreditTest) {
    PrepaidCustomer a1("1001","Lippman","9611044790",5000.0);
    a1.credit(3000);
    EXPECT_EQ(8000.0,a1.getBalance());
}
TEST(PrepaidCustomer,MakeCallTest) {
    PrepaidCustomer a1("1001","Lippman","9611044790",5000.0);
    a1.makeCall(1200);
    EXPECT_EQ(3800.0,a1.getBalance());
}
TEST(PostpaidCustomer,CreditTest) {
    PostpaidCustomer a1("1001","Lippman","9611044790",5000.0,25);
    a1.credit(3000);
    EXPECT_EQ(8000.0,a1.getBalance());
}
TEST(PostpaidCustomer,MakeCallTest) {
    PostpaidCustomer a1("1001","Lippman","9611044790",5000.0,25);
    a1.makeCall(1200);
    EXPECT_EQ(3800.0,a1.getBalance());
}
TEST(PrepaidCustomer,DisplayTest) {
    PrepaidCustomer a1("1001","Lippman","9611044790",5000.0);
    std::string ExpectedOut="1001,Lippman,9611044790,5000\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}
TEST(PostpaidCustomer,DisplayTest) {
    PostpaidCustomer a1("1001","Lippman","9611044790",5000.0,25);
    std::string ExpectedOut="1001,Lippman,9611044790,5000\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}


