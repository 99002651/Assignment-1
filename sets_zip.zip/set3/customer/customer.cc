#include"customer.h"
#include"prepaid.h"
#include"postpaid.h"
#include<iostream>
CustomerBase::CustomerBase():m_custId("0000"),m_custName("No Name"),m_phone("No Number"),m_balance(0){}

CustomerBase::CustomerBase(std::string id,std::string name,std::string phone, double bal):
    m_custId(id),m_custName(name),m_phone(phone),m_balance(bal){}

CustomerBase::CustomerBase(std::string id,std::string name,std::string phone):
    m_custId(id),m_custName(name),m_phone(phone),m_balance(0){}

CustomerBase::CustomerBase(const CustomerBase & refer ):
    m_custId(refer.m_custId),m_custName(refer.m_custName),m_phone(refer.m_phone),m_balance(refer.m_balance){}

PrepaidCustomer::PrepaidCustomer():CustomerBase(){}

PrepaidCustomer::PrepaidCustomer(std::string id,std::string name,std::string phone,double bal):CustomerBase(id,name,phone,bal){}

PrepaidCustomer::PrepaidCustomer(std::string id,std::string name,std::string phone):CustomerBase(id,name,phone){}

PostpaidCustomer::PostpaidCustomer():CustomerBase(){}

PostpaidCustomer::PostpaidCustomer(std::string id,std::string name,std::string phone,double bal,int m_billDate):m_billDate(m_billDate),CustomerBase(id,name,phone,bal){}

PostpaidCustomer::PostpaidCustomer(std::string id,std::string name,std::string phone):CustomerBase(id,name,phone){}

void PrepaidCustomer::makeCall(double amount)
{
    if(m_balance==0){}
    else m_balance=m_balance-amount;
}
void PrepaidCustomer::recharge(double amount)
{
    m_balance=m_balance+amount;
}
void PostpaidCustomer::billPay(double amount)
{
    if(m_balance==0){}
    else m_balance=m_balance-amount;
}
void PrepaidCustomer::credit(double amount)
{
    recharge(amount);
}
void PostpaidCustomer::makeCall(double amount)
{
    billPay(amount);
}
void PostpaidCustomer::credit(double amount)
{
    m_balance=m_balance+amount;
}
void PostpaidCustomer::display()
{
    std::cout<<m_custId<<","<<m_custName<<","<<m_phone<<","<<m_balance<<"\n";
}
void PrepaidCustomer::display()
{
    std::cout<<m_custId<<","<<m_custName<<","<<m_phone<<","<<m_balance<<"\n";
}
double CustomerBase::getBalance() const
{
    return m_balance;
}
std::string CustomerBase::getCustomerName() {
  return m_custName;
}
std::string CustomerBase::getCustomerNumber() {
  return m_custId;
}
std::string CustomerBase::getCustomerPhone() {
  return m_phone;
}

