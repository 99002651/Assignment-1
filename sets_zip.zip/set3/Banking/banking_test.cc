#include"banking.h"
#include"CreditAccount.h"
#include"SavingsAccount.h"
#include<gtest/gtest.h>
using namespace std;
TEST(CreditAccount,DefaultConstructor) {
    CreditAccount a1;
    EXPECT_EQ(0.0,a1.getBalance());
    EXPECT_STREQ("0000",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("No Name",a1.getCustomerName().c_str());
}
TEST(CreditAccount,ParameterizedConstructor) {
    CreditAccount a1("1001","Lippman",5000.0);
    EXPECT_STREQ("1001",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a1.getCustomerName().c_str());
    EXPECT_EQ(5000.0,a1.getBalance());
}
TEST(CreditAccount,CopyConstructor) {
    CreditAccount a1("1001","Lippman",5000.0);
    CreditAccount a2(a1);
    EXPECT_STREQ("1001",a2.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a2.getCustomerName().c_str());
    EXPECT_EQ(5000.0,a2.getBalance());
}
TEST(SavingsAccount,DefaultConstructor) {
    SavingsAccount a1;
    EXPECT_EQ(0.0,a1.getBalance());
    EXPECT_STREQ("0000",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("No Name",a1.getCustomerName().c_str());
}
TEST(SavingsAccount,ParameterizedConstructor) {
    SavingsAccount a1("1001","Lippman",5000.0);
    EXPECT_STREQ("1001",a1.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a1.getCustomerName().c_str());
    EXPECT_EQ(5000.0,a1.getBalance());
}
TEST(SavingsAccount,CopyConstructor) {
    SavingsAccount a1("1001","Lippman",5000.0);
    SavingsAccount a2(a1);
    EXPECT_STREQ("1001",a2.getCustomerNumber().c_str());
    EXPECT_STREQ("Lippman",a2.getCustomerName().c_str());
    EXPECT_EQ(5000.0,a2.getBalance());
}
TEST(CreditAccount,CreditTest) {
    CreditAccount a1("1001","Lippman",5000.0);
    a1.credit(3000);
    EXPECT_EQ(8000.0,a1.getBalance());
}
TEST(CreditAccount,DebitTest) {
    CreditAccount a1("1001","Lippman",5000.0);
    a1.debit(1200);
    EXPECT_EQ(3800.0,a1.getBalance());
}
TEST(SavingsAccount,CreditTest) {
    SavingsAccount a1("1001","Lippman",5000.0);
    a1.credit(3000);
    EXPECT_EQ(8000.0,a1.getBalance());
}
TEST(SavingsAccount,DebitTest) {
    SavingsAccount a1("1001","Lippman",5000.0);
    a1.debit(1200);
    EXPECT_EQ(3800.0,a1.getBalance());
}
TEST(CreditAccount,DisplayTest) {
    CreditAccount a1("1001","Lippman",5000.0);
    std::string ExpectedOut="1001,Lippman,5000\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}
TEST(SavingsAccount,DisplayTest) {
    SavingsAccount a1("1001","Lippman",5000.0);
    std::string ExpectedOut="1001,Lippman,5000\n";
    testing::internal::CaptureStdout();
    a1.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());
}
