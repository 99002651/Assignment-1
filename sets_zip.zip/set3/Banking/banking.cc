#include"banking.h"
#include"CreditAccount.h"
#include"SavingsAccount.h"
#include<iostream>
AccountBase::AccountBase():m_accNumber("0000"),m_accName("No Name"),m_balance(0){}
AccountBase::AccountBase(std::string id,std::string name, double bal):
    m_accNumber(id),m_accName(name),m_balance(bal){}
AccountBase::AccountBase(std::string id,std::string name):
    m_accNumber(id),m_accName(name),m_balance(0){}
AccountBase::AccountBase(const AccountBase & refer ):
    m_accNumber(refer.m_accNumber),m_accName(refer.m_accName),m_balance(refer.m_balance){}
CreditAccount::CreditAccount():AccountBase(){}
CreditAccount::CreditAccount(std::string id,std::string name,double bal):AccountBase(id,name,bal){}
CreditAccount::CreditAccount(std::string id,std::string name):AccountBase(id,name){}
SavingsAccount::SavingsAccount():AccountBase(){}
SavingsAccount::SavingsAccount(std::string id,std::string name,double bal):AccountBase(id,name,bal){}
SavingsAccount::SavingsAccount(std::string id,std::string name):AccountBase(id,name){}
void CreditAccount::debit(double amount)
{
    if(m_balance==0){}
    else m_balance=m_balance-amount;
}
void CreditAccount::credit(double amount)
{
    m_balance=m_balance+amount;
}
void SavingsAccount::debit(double amount)
{
    if(m_balance==0){}
    else m_balance=m_balance-amount;
}
void SavingsAccount::credit(double amount)
{
    m_balance=m_balance+amount;
}
void SavingsAccount::display()
{
    std::cout<<m_accNumber<<","<<m_accName<<","<<m_balance<<"\n";
}
void CreditAccount::display()
{
    std::cout<<m_accNumber<<","<<m_accName<<","<<m_balance<<"\n";
}
double AccountBase::getBalance() const
{
    return m_balance;
}
std::string AccountBase::getCustomerName() {
  return m_accName;
}
std::string AccountBase::getCustomerNumber() {
  return m_accNumber;
}

