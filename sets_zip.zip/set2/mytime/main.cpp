/*#include <iostream>
#include "mytime.h"
using namespace std;

int main() {
  MyTime t;
  MyTime t1(1,2,3);
  MyTime T(1,2);
  MyTime t3;
  t3 = t + t1;    // t1.operator+(t2)
  t3.display();

  MyTime t5;
  t5 = t1 - t;
  t5.display();

  MyTime t4;
  t4 = t1 + 50;    //t1.operator+(50)
  t4.display();

  MyTime t6;
  t6 = t1 - 50;    //t1.operator+(50)
  t6.display();

  MyTime t7(1,2,3);
  t7++;
  t7.display();

  MyTime t8(1,2,3);
  t8 = t++;
  t8.display();

  MyTime t9(1,2,3);
  t9 += t;
  t9.display();

  MyTime t10(1,2,3);
  if(t10 == t1){
    cout << "Equal" << endl;
  }

  MyTime t11(2,2,3);
  if(t11 > t1){
    cout << "Greater"<< endl;
  }

  MyTime t12(0,0,0);
  if(t12 < t1){
    cout << "Lesser" << endl;
  }


  return 0;
}*/
